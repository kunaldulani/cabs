package com.capgemini.cabser.exception;

public class CabException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8060718434430549446L;

	public CabException()
	{
		super();
	}
	public CabException(String message)
	{
		super(message);
	}
}
