package com.capgemnini.cabser.dao;

import com.capgemini.cabser.exception.CabException;
import com.capgemnini.cabser.bean.CustomerBean;

public interface ICustomerDAO 
{
	public boolean insertCustomer(final CustomerBean customerBean) throws CabException;
	
	public int viewCabs(String pin) throws CabException;
	
	public int getID() throws CabException;
}
