package com.capgemnini.cabser.bean;

public class CustomerBean 
{
		private int customerId;
		private String name;
		private String address;
		private String pin;
		private String phoneNo;
		private String quantity;
		
		
		public CustomerBean() {
			super();
		}


		public CustomerBean(int customerId, String name, String address, String pin, String phoneNo, String quantity) {
			super();
			this.name = name;
			this.address = address;
			this.pin = pin;
			this.phoneNo = phoneNo;
			this.quantity = quantity;
		}


		public int getCustomerId() {
			return customerId;
		}


		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getPin() {
			return pin;
		}


		public void setPin(String pin) {
			this.pin = pin;
		}


		public String getPhoneNo() {
			return phoneNo;
		}


		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}


		public String getQuantity() {
			return quantity;
		}


		public void setQuantity(String quantity) {
			this.quantity = quantity;
		}


		@Override
		public String toString() {
			return "CustomerBean [customerId=" + customerId + ", name=" + name + ", address=" + address + ", pin=" + pin
					+ ", phoneNo=" + phoneNo + ", quantity=" + quantity + "]";
		}
		
		
		
		
}
